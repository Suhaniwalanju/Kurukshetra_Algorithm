// Test assertions
assert res == 42;