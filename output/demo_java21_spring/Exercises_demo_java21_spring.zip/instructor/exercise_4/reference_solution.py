public class Solution {
    public static void main(String[] args) {
        int res = 42;
        System.out.println("Synthesized: " + res);
    }
}