# Student Exercises: Java 21 & Spring Boot 3 Microservices Architecture

Complete the starter code and run tests to verify.
