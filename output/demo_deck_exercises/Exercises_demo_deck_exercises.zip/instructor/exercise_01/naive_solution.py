def compute(nums: list) -> int:
    # Naive student bug: counts all items without checking if positive
    return len(nums)
