def compute(nums: list) -> int:
    return sum(1 for x in nums if x > 0)
