def compute(nums: list) -> int:
    return sum(nums)
