def compute(nums: list) -> int:
    # Naive student bug: returns first element or -1 on empty list
    return nums[0] if nums else -1
