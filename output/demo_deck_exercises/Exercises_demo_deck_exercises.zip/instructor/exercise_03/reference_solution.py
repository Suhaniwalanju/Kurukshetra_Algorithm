def compute(nums: list) -> int:
    if not nums or len(nums) < 2:
        return 0
    return max(nums[i] + nums[i + 1] for i in range(len(nums) - 1))
