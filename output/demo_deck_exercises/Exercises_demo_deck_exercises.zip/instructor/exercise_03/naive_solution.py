def compute(nums: list) -> int:
    # Naive student bug: only returns the sum of the first two elements
    if not nums or len(nums) < 2:
        return 0
    return nums[0] + nums[1]
