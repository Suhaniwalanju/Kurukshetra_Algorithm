def compute(nums: list) -> int:
    # TODO: Count positive numbers (> 0)
    return 0
