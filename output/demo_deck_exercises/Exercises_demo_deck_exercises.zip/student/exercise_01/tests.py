def run_tests():
    assert compute([1, -2, 3, 0]) == 2, 'Test 1 failed'
    assert compute([-1, -5]) == 0, 'Test 2 failed'
    assert compute([]) == 0, 'Test 3 failed'
    print('All tests passed!')
run_tests()
