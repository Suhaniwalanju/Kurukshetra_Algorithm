# Python List Comprehensions & Advanced Data Filtering: Positive Numbers Filter & Count (EASY)

**Difficulty:** EASY | **Estimated Time:** 10 minutes | **Source Slides:** Slides [1]

## Task Description
### Task: Count Positive Elements (Python List Comprehensions & Advanced Data Filtering)
Implement `compute(nums: list) -> int` in Python to count all strictly positive numbers (> 0).

#### Examples:
- **Input:** `[1, -2, 3, 0]` -> **Output:** `2`
- **Input:** `[-1, -5]` -> **Output:** `0`
- **Input:** `[]` -> **Output:** `0`


## How to Run Tests
Run the test suite using the pinned runtime:
```bash
# Pinned Python 3.12
python3 tests.py
```
