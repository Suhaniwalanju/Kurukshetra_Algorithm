def compute(nums: list) -> int:
    # TODO: Maximum adjacent pair sum
    return 0
