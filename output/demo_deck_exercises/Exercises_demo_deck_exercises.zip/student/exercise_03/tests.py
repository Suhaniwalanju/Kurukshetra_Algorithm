def run_tests():
    assert compute([1, 4, 2, 10, 23]) == 33, 'Test 1 failed'
    assert compute([100, 200, 300]) == 500, 'Test 2 failed'
    assert compute([5]) == 0, 'Test 3 failed'
    print('All tests passed!')
run_tests()
