def run_tests():
    assert compute([1, 2, 3]) == 6, 'Test 1 failed'
    assert compute([5]) == 5, 'Test 2 failed'
    assert compute([]) == 0, 'Test 3 failed'
    print('All 3 tests passed!')
run_tests()
