def compute(nums: list) -> int:
    # TODO: Implement solution
    return 0
