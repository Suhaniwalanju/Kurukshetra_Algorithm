# Hands-On Exercises: Python List Comprehensions & Advanced Data Filtering

**Technology:** Python (Version: 3.12)

## Exercise Index

| # | Title | Difficulty | Source Slides | Status | Est. Time |
|---|---|---|---|---|---|
| 01 | Python List Comprehensions & Advanced Data Filtering: Positive Numbers Filter & Count | EASY | Slides [1] | VERIFIED | 10 mins |
| 02 | Python List Comprehensions & Advanced Data Filtering: Core List Accumulation | MEDIUM | Slides [2, 3] | VERIFIED | 20 mins |
| 03 | Python List Comprehensions & Advanced Data Filtering: Adjacent Pair Maximum Sum | STRETCH | Slides [4] | VERIFIED | 30 mins |
