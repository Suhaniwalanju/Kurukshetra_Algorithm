# Student Exercises: Modern C++20 Concepts, Ranges & Move Semantics

Complete the starter code and run tests to verify.
