# Student Exercises: Python 3.12 Concurrency

Complete the starter code and run tests to verify.
