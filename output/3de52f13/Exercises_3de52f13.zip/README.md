# Hands-On Exercises: Python 3.12 AsyncIO & High-Performance Coroutines

**Technology:** Python (Version: 3.12.8)

## Exercise Index

| # | Title | Difficulty | Source Slides | Status | Est. Time |
|---|---|---|---|---|---|
| 01 | Python 3.12 AsyncIO & High-Performance Coroutines: Positive Numbers Filter & Count | EASY | Slides [3, 4] | VERIFIED | 10 mins |
| 02 | Python 3.12 AsyncIO & High-Performance Coroutines: Core List Accumulation | MEDIUM | Slides [5, 6] | VERIFIED | 20 mins |
| 03 | Python 3.12 AsyncIO & High-Performance Coroutines: Adjacent Pair Maximum Sum | STRETCH | Slides [8] | VERIFIED | 30 mins |
