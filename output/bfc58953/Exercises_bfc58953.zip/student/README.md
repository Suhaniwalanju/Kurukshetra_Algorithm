# Student Exercises: C17 Memory Safety, Pointer Arithmetic & Sanitizers

Complete the starter code and run tests to verify.
