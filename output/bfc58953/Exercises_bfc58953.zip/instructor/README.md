# Instructor Reference Solutions: C17 Memory Safety, Pointer Arithmetic & Sanitizers

Confidential solutions and mutation test matrices.
