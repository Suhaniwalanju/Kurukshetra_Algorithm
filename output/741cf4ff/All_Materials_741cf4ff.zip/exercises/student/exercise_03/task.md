# Python 3.12 AsyncIO & High-Performance Coroutines: Adjacent Pair Maximum Sum (STRETCH)

**Difficulty:** STRETCH | **Estimated Time:** 30 minutes | **Source Slides:** Slides [10]

## Task Description
### Task: Maximum Sum of Adjacent Pair (Python 3.12 AsyncIO & High-Performance Coroutines)
Implement `compute(nums: list) -> int` in Python to find the maximum sum of any adjacent pair. Return 0 if the list has fewer than 2 elements.

#### Examples:
- **Input:** `[1, 4, 2, 10, 23]` -> **Output:** `33`
- **Input:** `[100, 200, 300]` -> **Output:** `500`
- **Input:** `[5]` -> **Output:** `0`


## How to Run Tests
Run the test suite using the pinned runtime:
```bash
# Pinned Python 3.12.8
python3 tests.py
```
