# Python 3.12 AsyncIO & High-Performance Coroutines: Core List Accumulation (MEDIUM)

**Difficulty:** MEDIUM | **Estimated Time:** 20 minutes | **Source Slides:** Slides [6, 7]

## Task Description
### Task: Sum Elements (Python 3.12 AsyncIO & High-Performance Coroutines)
Implement `compute(nums: list) -> int` in Python to calculate the sum of all elements. Return 0 for an empty list.

#### Examples:
- **Input:** `[1, 2, 3]` -> **Output:** `6`
- **Input:** `[5]` -> **Output:** `5`
- **Input:** `[]` -> **Output:** `0`


## How to Run Tests
Run the test suite using the pinned runtime:
```bash
# Pinned Python 3.12.8
python3 tests.py
```
