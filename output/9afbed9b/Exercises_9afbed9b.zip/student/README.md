# Student Exercises: MongoDB 7.0 Aggregation Pipelines & Document Modeling

Complete the starter code and run tests to verify.
