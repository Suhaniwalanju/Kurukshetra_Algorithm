# Hands-On Exercises: Spring Boot 3 REST

**Technology:** Python (Version: 3.12)

## Exercise Index

| # | Title | Difficulty | Source Slides | Status | Est. Time |
|---|---|---|---|---|---|
