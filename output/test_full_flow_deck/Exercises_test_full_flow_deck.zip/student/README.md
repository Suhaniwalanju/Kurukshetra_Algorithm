# Student Exercises: Spring Boot 3 REST

Complete the starter code and run tests to verify.
