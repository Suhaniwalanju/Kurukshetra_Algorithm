# Instructor Reference Solutions: Spring Boot 3 REST

Confidential solutions and mutation test matrices.
